from __future__ import division
import math

def average(data):
    return data['Congestion'].mean()