import pandas as pd
import sys
import math
import requests

def getData():
    r = requests.get(allow_redirects=True)
    open('output.csv', 'wb').write(r.content)
    data = pd.read_csv("output.csv")
    data = data[['Location', 'CurrSpeed', 'NormSpeed', 'Date', 'Hour', 'Congestion', 'Weekday']]
    return data