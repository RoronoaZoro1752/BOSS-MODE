export * from './location.component';
